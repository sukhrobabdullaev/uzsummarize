// This file is kept empty as the popup now only shows static instructions
// All functionality is handled by the background and content scripts
